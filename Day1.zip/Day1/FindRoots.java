package Day1;
import java.util.Scanner;
public class FindRoots {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number1");
	     double num1=sc.nextDouble();
	     System.out.println("Enter number2");
	     double num2=sc.nextDouble();
	     System.out.println("Enter number3");
	     double num3=sc.nextDouble();
	     double result=num2*num2-4.0*num1*num3;
	     if(result>0.0)
	     {
	    	 double result1=(-num2+Math.pow(result, 0.5))/(2.0*num1);
	    	 double result2=(-num2-Math.pow(result, 0.5))/(2.0*num1);
		     System.out.println("the roots"+result1+" "+result2);
	     }
	     else if(result==0.0)
	     {
	    	 double result3=-num2/(2.0*num1);
		     System.out.println("the root"+result3);
	 
	     }
	     else
		     System.out.println("the equation has no real roots");

	}

}
