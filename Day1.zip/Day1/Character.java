package Day1;
import java.util.Scanner;

public class Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter alphabet");
		String alpha=sc.nextLine().toLowerCase();
		boolean upperCase=alpha.charAt(0)>=65 && alpha.charAt(0)<=90;
		boolean lowerCase=alpha.charAt(0)>=97 && alpha.charAt(0)<=122;
		if(alpha.equals("a")||alpha.equals("e")||alpha.equals("i")||alpha.equals("o")||alpha.equals("u"))
		{
	    	 System.out.println("vowel");

		}
		else if(alpha.length()>1) {
	    	 System.out.println("not a single character");

		}
		else if(!(upperCase||lowerCase)) {
	    	 System.out.println("error");
	    	

		}
		else
		{
	    	 System.out.println("consonant");

		}
	}

}
