package Day1;

public class DataTypes {
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=10;
		long num2=9632375878L;
		float num3= 8.94f;
		double num4=9632375878d;
		byte num5=1;
		char ch='n';
		String name="Nagashree";
		boolean num6=false;
        short num7=45;

		System.out.println("int:"+num1);
		System.out.println("long:"+num2);
		System.out.println("float:"+num3);
		System.out.println("double:"+num4);
		System.out.println("byte:"+num5);
		System.out.println("char:"+ch);
		System.out.println("String:"+name);
		System.out.println("boolean:"+num6);
		System.out.println("short:"+num7);
	
	}

}
