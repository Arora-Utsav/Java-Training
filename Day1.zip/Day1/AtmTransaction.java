package Day1;
import java.util.Scanner;
public class AtmTransaction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		transaction();
	}
	private static void transaction() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter choice\n 1 for SAVINGS ACCOUNT \n 2 for CURRENT ACCOUNT");
		int choice=sc.nextInt();
		float balance=10000;
		switch(choice){
		case 1:
			System.out.println("SAVINGS ACCOUNT\n Enter the pin");
			int pin=sc.nextInt();
			System.out.println("Enter choice 1 for WITHDRAW \n 2 for DEPOSIT \n 3 for BALANCE");
			int choice1=sc.nextInt();
			switch(choice1) {
			case 1:
				System.out.println("Please enter the amount to withdraw");
				float amount=sc.nextFloat();
				if(amount>balance||balance==0) {
					System.out.println("you have insufficient balance");
					anotherTransaction();
				}
				else {
					balance=balance-amount;
					System.out.println("balance:"+balance+"\n"+"withdrawn amount:"+amount);
					anotherTransaction();
				}
				break;
			case 2:
				System.out.println("Please enter the amount to deposit");
				float deposit=sc.nextFloat();
				balance=balance+deposit;
				System.out.println("balance:"+balance+"\n"+"deposit:"+deposit);
				anotherTransaction();
				break;
			case 3:
				System.out.println("balance:"+balance);
				anotherTransaction();
				break;
			default:
				System.out.println("Enter correct choice ");
				break;
			}
			break;
		case 2:
			System.out.println("CURRENT ACCOUNT\n Enter the pin");

			System.out.println("Enter choice \n 1 for WITHDRAW \n 2 for DEPOSIT \n 3 for BALANCE");
			int choice2=sc.nextInt();
			switch(choice2) {
			case 1:
				System.out.println("Please enter the amount to withdraw");
				float amount=sc.nextFloat();
				if(amount>balance||balance==0) {
					System.out.println("you have insufficient balance");
					anotherTransaction();
				}
				else {
					balance=balance-amount;
					System.out.println("balance:"+balance+"\n"+"withdrawn amount:"+amount);
					anotherTransaction();
				}
				break;
			case 2:
				System.out.println("Please enter the amount to deposit");
				float deposit=sc.nextFloat();
				balance=balance+deposit;
				System.out.println("balance:"+balance+"\n"+"deposit:"+deposit);
				anotherTransaction();
				break;
			case 3:
				System.out.println("balance:"+balance);
				anotherTransaction();
				break;
			default:
				System.out.println("Enter correct choice ");
			}
			break;
		default:
			System.out.println("Enter correct choice ");

		}
		
	}
	private static  void  anotherTransaction(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter choice\n 1 for ANOTHER TRANSCATION \n 2 for EXIT");
		int choice=sc.nextInt(); 
		if(choice==1) {
			transaction();
		}
		else if(choice==2)
		{
			System.out.println("Thank you!!!!");
		
		}
		else
			System.out.println("Enter correct choice ");
	}
}


