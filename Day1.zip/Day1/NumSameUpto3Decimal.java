package Day1;
import java.util.Scanner;
public class NumSameUpto3Decimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number1");
	     double num1=sc.nextDouble();
	     System.out.println("Enter number2");
	     double num2=sc.nextDouble();
	     num1=Math.round(num1*1000);
	     num1=num1/1000;
	     num2=Math.round(num2*1000);
	     num2=num2/1000;
	     if(num1==num2)
	    	 System.out.println("the 2 numbers are same");
	     else
	    	 System.out.println("the 2 numbers are different");
	}

}
