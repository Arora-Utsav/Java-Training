package Day1;
import java.util.Scanner;
public class SmallLargeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
				System.out.println("Enter number");
			     double num=sc.nextDouble();
		        if (num>0) {
		        	if(num<1) {
		           	 System.out.println(num+"small positive");

		        	}
		        	else if(num>1000000) {
			           	 System.out.println(num+"large positive");

		        	}
		        	else {
			           	 System.out.println(num+"is positive");

		        	}
		        		
		        }
		        else if (num<0) {
		           	 System.out.println(num+"is negative");

		        }
		        else
		        {
		           	 System.out.println(num+"is zero");

		        }
	}

}
