package Day2;

public class Multiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num1=13,num2=45, num3=79;
		for(int i=1;i<=10;i++) {
			System.out.println(num1+"*"+i+"="+num1*i);
			System.out.println();
		}
		for(int i=1;i<=10;i++) {
			System.out.println(num2+"*"+i+"="+num2*i);
			System.out.println();
		}
		for(int i=1;i<=10;i++) {
			System.out.println(num3+"*"+i+"="+num3*i);
			System.out.println();
		}
	}

}
