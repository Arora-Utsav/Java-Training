package Day2;
import java.util.Scanner;
public class PrimeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0,num=0;
		String primeNum="";
		for(i=1;i<=100;i++)
		{
			int count=0;
			for(num=i;num>=1;num--) {
				if(i%num==0) {
					count+=1;
				}
			}
			if(count==2) {
				primeNum=primeNum+i+" ";
			}
		}
		System.out.println(primeNum);
	}

}
