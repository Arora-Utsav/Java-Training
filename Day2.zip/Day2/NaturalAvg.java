package Day2;
import java.util.Scanner;
public class NaturalAvg {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int sum=0;
		System.out.println("Enter number of terms");
		int n=sc.nextInt();
		System.out.println("Enter the  numbers");
		for(int i=0;i<n;i++) {
			int num=sc.nextInt();	
		}
		for(int i=0;i<=n;i++) {
		sum+=i;
		}
		System.out.println("sum="+sum);
		float avg=sum/n;
		System.out.println("Average="+avg);

	}

}
