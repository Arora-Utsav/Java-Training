package Day2;
import java.util.Scanner;
public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee1= new Employee("Nagashree",100,"9876543241",10000, "EPD", 'F',"Mangalore", "Trainee");
		Employee employee2= new Employee("Chaya",101,"9876546241",32000, "EPD", 'F',"Mangalore", "Manager");
		Employee employee3= new Employee("Smith",102,"8765456743",20000, "EPD", 'F',"Bangalore", "Trainee");
		Employee employee4= new Employee("Smith",103,"7654328976",24500, "EPD", 'M',"Mysore", "Trainee");
		Employee employee5= new Employee("John",104,"9453678976",100000, "EPD", 'M',"Bangalore", "Trainee");
		

		/*Employee employee1= new Employee();
		Employee employee2= new Employee();
		Employee employee3= new Employee();
		Employee employee4= new Employee();
		Employee employee5= new Employee();

		employee1.getInput();
		employee2.getInput();
		employee3.getInput();
		employee4.getInput();
		employee4.getInput();*/
		
		employee1.displayDetails();
		employee2.displayDetails();
		employee3.displayDetails();
		employee4.displayDetails();
		employee4.displayDetails();
		
		double comm1=employee1.calculateCommission(5.0);
		double comm2=employee2.calculateCommission(3.0);
		double comm3=employee3.calculateCommission(4.0);
		double comm4=employee4.calculateCommission(2.0);
		double comm5=employee5.calculateCommission(0.0);

		double sal1=employee1.calculateSalary(5.0);
		double sal2=employee2.calculateSalary(3.0);
		double sal3=employee3.calculateSalary(4.0);
		double sal4=employee4.calculateSalary(2.0);
		double sal5=employee5.calculateSalary(0.0);
		
		System.out.println("Commission and total Salary of Employee1 are:"+comm1+" "+"and"+" "+sal1);
		System.out.println("Commission and total Salary of Employee2 are:"+comm2+" "+"and"+" "+sal2);
		System.out.println("Commission and total Salary of Employee3 are:"+comm3+" "+"and"+" "+sal3);
		System.out.println("Commission and total Salary of Employee4 are:"+comm4+" "+"and"+" "+sal4);
		System.out.println("Commission and total Salary of Employee5 are:"+comm5+" "+"and"+" "+sal5);
		
		
	}

}
