package Day2;
import java.util.Scanner;
public class Employee {
		String name;
		int empid;
		String contact;
		double salary;
		String department;
		char gender;
		Address address;
		String designation;
		Scanner sc=new Scanner(System.in);
		Employee(String name,int empid,String contact, double salary, String department, char gender, String address, String designation)
		{
		this.name=name;
		this.empid=empid;
		this.contact=contact;
		this.salary=salary;
		this.department=department;
		this.gender=gender;
		//this.address=address;
		this.designation=designation;
		}
		/*void getInput()
		{
			System.out.println("Enter employee name:");
			name=sc.next();
			System.out.println("Enter employee id:");
			empid=sc.nextInt();
			System.out.println("Enter employee contact:");
			contact=sc.next();
			System.out.println("Enter employee salary:");
			salary=sc.nextDouble();
			System.out.println("Enter employee department:");
			department=sc.next();
			System.out.println("Enter employee gender:");
			gender=sc.next().charAt(0);
			System.out.println("Enter employee designation:");	
			designation=sc.next();
		}*/
		double  calculateCommission(double percentage) {
		double commission= percentage/100* salary;
		return commission;

		}
		void displayDetails() {
		System.out.println(name);
		System.out.println(empid);
		System.out.println(contact);
		System.out.println(salary);
		System.out.println(department);
		System.out.println(gender);
		System.out.println(address);
		System.out.println(designation);
		System.out.println();
		}
		
		double calculateSalary(double commission) {
			double totalsalary= salary+commission;
			return totalsalary;
		}

}
