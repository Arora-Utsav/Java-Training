package Day2;

public class Room {
	int roomNo;
	String type;
	String color;

}
