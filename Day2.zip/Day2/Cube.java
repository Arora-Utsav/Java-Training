package Day2;
import java.util.Scanner;
public class Cube {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Scanner sc=new Scanner(System.in);
		
			System.out.println("Enter the terms");
			int n=sc.nextInt();
			System.out.println("Enter the numbers");
			for(int i=0;i<n;i++) {
				int num=sc.nextInt();	
			}
			for(int i=1;i<=n;i++) {
			int cube=i*i*i;
			System.out.println(cube);
			}
			
	}

}
