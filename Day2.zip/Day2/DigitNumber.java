package Day2;
import java.util.Scanner;

public class DigitNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number and digit");
		int num=sc.nextInt();
		int digit=sc.nextInt();
		printNumbers(num, digit);
	}
		private static void printNumbers(int n, int d) {
		for(int i=0;i<=n;i++) {
			if(i==d || isDigit(i,d)) {
				System.out.print(i+" ");
			}
			
		}
		}
	
	private static boolean isDigit(int x, int y) {
		while(x>0) {
			if(x%10==y)
				break;
			x=x/10;
		}
		return(x>0);
	}

}
