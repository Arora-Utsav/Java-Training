package Day2;
import java.util.Scanner;
public class OddEvenSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sume=0,sumo=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the terms");
		int num=sc.nextInt();
		int a[]=new int[num];
		System.out.println("Enter the numbers");
		for(int i=0;i<num;i++) {
			a[i]=sc.nextInt();	
		}
		for(int i=0;i<num;i++)
		{
			if(a[i]%2==0) {
				sume+=a[i];
			}
			else {
				sumo+=a[i];
			}
		}
		System.out.println("sum of even numbers:"+sume);
		System.out.println("sum of odd numbers:"+sumo);
	}

}
