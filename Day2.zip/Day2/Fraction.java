package Day2;
import java.util.Scanner;
public class Fraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 2 number");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		reduceFraction(num1,num2);

	}
	static void reduceFraction(int x, int y) {
		int d;
		d=gcd(x,y);
		x/=d;
		y/=d;
		System.out.println("fractions are:"+x+"  "+y);
	}
	static int gcd(int m, int n) {
		if(n==0)
			return m;
		return gcd(n,m%n);
	}

}
