package Day2;

public class Address {
	House hno;
	String city;
	String street;
	int pincode;

}
