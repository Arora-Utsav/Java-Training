package Day2;
import java.util.Scanner;
public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num=sc.nextInt();
		int temp=num;
		int revnum=0;
		while(num>0) {
			revnum=revnum*10+num%10;
			num=num/10;
		}
		if(revnum==temp)
		{
			System.out.println("given number is palindrome");
		}
		else
			System.out.println("given number is not a palindrome");	
	}

}
