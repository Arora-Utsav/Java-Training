package Day2;

public class House {
	int no;
	String name;
	Room room;

}
