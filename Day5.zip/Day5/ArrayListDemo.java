package Day5;

import java.util.Iterator;
import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <String> al=new ArrayList<String>();
		al.add("cat");
		al.add("dog");
		al.add("cow");
		al.add("sheep");
		//ll.iterator();
		System.out.println("size:"+al.size());
		System.out.println("list elements:"+al);
		System.out.println(al.get(2));
		al.set(3, "elephant");
		al.remove(2);
		System.out.println("size after modification:"+al.size());
		System.out.println("list elements after modification:"+al);
		Iterator i=al.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}

	}

}
