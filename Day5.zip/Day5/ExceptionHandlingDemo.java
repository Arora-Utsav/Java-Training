package Day5;
import java.util.*;

public class ExceptionHandlingDemo extends Exception{

	public static void main(String[] args) throws newIncorrectNameEXception{
		// TODO Auto-generated method stub
		/*int a=0;
		System.out.println("line no7");
		int b=1;
		System.out.println("line no9");
		try {
			System.out.println(b/0);
		}
		catch(IndexOutOfBoundsException e) {
			System.err.println("error");
		}
		catch (Exception e) {
			System.err.println("error");
		}
		finally {
			System.out.println("finally block");
		}
		System.out.println("line 11");
		 */
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		int a=name.length();
		if(a<6){
			throw newIncorrectNameEXception();
			System.out.println("error");
		}

	}


}

