package Day5;
import java.util.*;
public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <String> ll=new LinkedList<String>();
		ll.add("cat");
		ll.add("dog");
		ll.add("cow");
		ll.add("sheep");
		//ll.iterator();
		System.out.println("size:"+ll.size());
		System.out.println("list elements:"+ll);
		System.out.println(ll.get(2));
		ll.set(3, "elephant");
		ll.remove(2);
		System.out.println("size after modification:"+ll.size());
		System.out.println("list elements after modification:"+ll);
		Iterator i=ll.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}

	}

}
