package Day5;
public class GermanShepherd extends Dog {
	String type="dog type";
	public void display() {
		System.out.println("display of German Shepherd");
		super.display();
	}
}



