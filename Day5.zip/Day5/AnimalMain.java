package Day5;

public class AnimalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog dog=new Dog();
		dog.display();
		//dog.display();
		//System.out.println(dog.animaltype);
		// GermanShepherd german=new GermanShepherd();
		// german.display(); }}


	}

}
