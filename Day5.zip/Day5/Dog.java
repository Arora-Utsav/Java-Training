package Day5;
public class Dog extends Animal {
	
	Dog(){
		super("german Shepherd");
		//super();
		//System.out.println(super.type);
		//System.out.println("Type of animal:"+super.type);
		System.out.println("constructor of Dog");
	}
	String type="dog";
	//String animaltype=super.type;
	public void display() {
		System.out.println("display of Dog");
		super.display();
	}
}



