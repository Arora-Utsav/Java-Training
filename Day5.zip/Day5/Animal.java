package Day5;

public class Animal {
	//String type=mammal;
	// Animal(){
	// System.out.println("constructor of Animal");
	// }
	/*String type;
	Animal(){
		this.type="any";
		}*/
	public void display() {
		System.out.println("display of animal");
	}
	String type;
		Animal(String type){
			this.type=type;
			System.out.println("type of animal:"+type);
		
	}
}



