package Day5;

import java.util.*;
import java. lang.*;


public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("cat");
		ts.add("dog");
		ts.add("cow");
		ts.add("sheep");
		//ll.iterator();
		System.out.println("size:"+ts.size());
		System.out.println("list elements:"+ts);
		Iterator i=ts.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
