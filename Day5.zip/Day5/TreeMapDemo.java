package Day5;
import java.util.*;
import java. lang.*;

public class TreeMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashMap<Integer, String> hm=new HashMap<Integer, String>();
hm.put(1, "cat");
hm.put(2, "dog");
hm.put(3, null);
hm.put(3, "elephant");
System.out.println("size:"+hm.size());
Set<Integer> set1 = hm.keySet();
for(Integer key : set1) {
    System.out.println("Key : "  + key + "\t\t" + "Value : "  + hm.get(key));           
}
hm.replace(2, "sheep");
hm.remove(3);
System.out.println("size:"+hm.size());
for(Integer key : set1) {
    System.out.println("Key : "  + key + "\t\t" + "Value : "  + hm.get(key));           
}
	}

}
