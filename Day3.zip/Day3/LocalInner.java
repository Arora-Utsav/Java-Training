package Day3;

public class LocalInner {

	private int num=47;
	void show() {
		class Local{
			void display() {
				System.out.println("Hi");
			}
		}
		Local l=new Local();
		l.display();
	}
	void method2() {
	} public static void main(String[] args) {
		LocalInner li=new LocalInner();
		li.show();
	}
}
