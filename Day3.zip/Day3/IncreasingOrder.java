package Day3;
import java.util.Scanner;
public class IncreasingOrder {
	Boolean CheckNumber(int n)
	{
		boolean flag=false;
		int num=n%10;
		n=n/10;
		while(n>0) {
			if(num<=n%10) {
				flag=true;
				break;
			}
			num=n%10;
			n=n/10;
		}
		return flag;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		IncreasingOrder io=new IncreasingOrder();
		boolean value=false;
		value=io.CheckNumber(num);
		if(value) {
			System.out.println("the entered number not in increasing order");
		}
		else
			System.out.println("the entered number in increasing order");				
	}

}


