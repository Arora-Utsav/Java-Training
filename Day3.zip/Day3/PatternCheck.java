package Day3;
import java.util.regex.*;
public class PatternCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String regex="..mo";
		String str="smosmos";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(str);
		while(m.find()) {
		System.out.println(true);
		}


	}

}
