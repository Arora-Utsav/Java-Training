package Day3;
import java.util.Scanner;
public class Calculator {
 int CalculateSum(int n) {
	 int x=3,y=5;
	 int S1, S2, S3;
     
     S1 = ((n / x)) * (2 * x + (n/ x - 1) * x) / 2;
     S2 = ((n / y)) * (2 * y + (n / y - 1) * y) / 2;
     S3 = ((n/ (x* y))) * (2 * (x * y) + (n/ (x * y) - 1) * (x * y))/ 2;
	 return S1+S2-S3;
                      
 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		Calculator cal=new Calculator();
		int sum=cal.CalculateSum(num);
		System.out.println("sum of "+num+" natural numbers:"+sum);
	}

}
