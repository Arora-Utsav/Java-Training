package Day3;
import java.util.Scanner;
public class SquareDifference {
	 int CalculateDifference(int n){
		 int l, k, m;
		    l = (n * (n + 1) * (2 * n + 1)) / 6;
		    k = (n * (n + 1)) / 2;
		    k = k * k;
		    m = Math.abs(l - k);
		     
		    return m;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		SquareDifference sd=new SquareDifference();
		int sum=sd.CalculateDifference(num);
		System.out.println(sum);
	}

}
