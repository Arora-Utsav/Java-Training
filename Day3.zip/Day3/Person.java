package Day3;

abstract class Person {
abstract void eat();
}
