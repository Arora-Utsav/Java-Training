package Day3;

public class Outer {
	private int outernum=60;
	class Inner{
		int innernum=20;
		void show() {
			System.out.println("Inner number:"+innernum);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer out=new Outer();
		System.out.println("Outer number:"+out.outernum);
		Outer.Inner in=out.new Inner();
		in.show();

	}

}
