package Day3;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		int temp=num;
		int result=0,remainder=0;
		while(num!=0) {
			remainder=num%10;
			result=result+(int)Math.pow(remainder,3);
			num=num/10;
		}
		if(result==temp) {
			System.out.println("given number is armstrong number");
		}
		else
			
			System.out.println("given number is not armstrong number");
	}

}

