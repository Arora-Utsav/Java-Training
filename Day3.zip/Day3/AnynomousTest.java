package Day3;

public class AnynomousTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Person p=new Person() {

	void eat() {
		System.out.println("chocolate");
	}
};
p.eat();
	}
}
