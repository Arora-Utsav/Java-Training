package Day3;

import java.util.Scanner;

public class CubeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		int i=1;
		while(i<=num) {
			System.out.println("cube of "+i+" is "+i*i*i);
			i++;
		}
	}

}
