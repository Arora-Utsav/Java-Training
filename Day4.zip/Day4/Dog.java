package Day4;

public class Dog extends Animal{
	 String name2="dog";
	 void eat()
	 {
		 System.out.println("dog eats");
	 }
}
