package Day4;
import java.util.*;
import java.time.*;
public class CurrentSystemDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate pdate = LocalDate.of(2031, 04, 10);
		LocalDate now = LocalDate.now();
		Period diff = Period.between(pdate, now);
		System.out.printf("Difference is %d years, %d months and %d days old\n\n",
		diff.getYears(), diff.getMonths(), diff.getDays());
	}

}
