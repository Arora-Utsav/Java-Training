package Day4;

public interface Floatable extends Artillery {
	int duration=5;
	public void canFloat();
	public default void repair()
	{
		System.out.println("repair of floatable");
	}
	
}
