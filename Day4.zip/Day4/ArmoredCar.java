package Day4;

public class ArmoredCar extends Car implements Floatable, Artillery {
	void AutomoredStarts()
	{
		System.out.println("Automored car class starts");
	}
	public void canFloat() {
		System.out.println("can float on water");
	}
	public void canShoot() {
		System.out.println("can shoot");
	}
	//public void repair();
	
	
}
