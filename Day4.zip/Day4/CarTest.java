package Day4;

public class CarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArmoredCar ac=new ArmoredCar();
		ac.AutomoredStarts();
		ac.start();
		System.out.println(ac.window);
		//Car car=new Car();
		//car.AutomoredStarts();
		ac.canFloat();
		ac.canShoot();
	    ac.repair();
	    ac.repair1();
	    System.out.println("duration of floatable:"+ac.duration);
	    System.out.println("duration of artillery:"+ac.duration1);

	}

}
