package Day4;

public class Account extends Person {
	long accNum;
	double balance = 500;
	Person accHolder = new Person();
	void deposit(double amount) {
		this.balance += amount;
		System.out.println(this.balance);
	}
	void withdraw(double amount) {
		if(this.balance < amount )
			System.out.println("No sufficient balance");
		else
			this.balance -= amount;
		System.out.println(this.balance);
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public Person getAccHolder() {
		System.out.println(accHolder.getName());
		System.out.println(accHolder.getAge());
		return accHolder;
	}
	public void setAccHolder(String name,float age) {
		accHolder.setName(name);
		accHolder.setAge(age);
	}
}

