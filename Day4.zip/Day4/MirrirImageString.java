package Day4;

import java.util.Scanner;

public class MirrirImageString {
	String getImage(String str) {
		String str1=str;
		StringBuffer str2=new StringBuffer(str1);
		str2.reverse();
		String str3=str2.toString();
		return str3;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String str=sc.nextLine();
		MirrirImageString mi=new MirrirImageString();
		String str1=mi.getImage(str);
		StringBuffer str2=new StringBuffer(str);
		str2.append("|");
		StringBuffer str3=new StringBuffer(str2);
		str3.append(str1);
		System.out.println(str3);
		
	}

}
