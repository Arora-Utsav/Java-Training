package Day4;

public class Car {
	int window;
	String model;
	Car()
	{
	window=6;
	model="XYZ";
	
	}
	void start()
	{
		System.out.println("Starting the car class method");
	}

}
