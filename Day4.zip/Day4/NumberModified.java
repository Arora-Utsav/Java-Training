package Day4;

import java.util.Scanner;

public class NumberModified {
	/*int modifyNumber(int num) {
		String str=Integer.toString(num);
		int len=str.length();
		for(int i=0;i<len;i++) {
			char c=str.charAt(i);
			int number=Character.getNumericValue(c);
			
		}
	}
*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		/* NumberModified nm=new  NumberModified();
		 int result=nm.modifyNumber(num);
		System.out.println(result);*/
		String str=String.valueOf(num);
		StringBuffer str1=new StringBuffer();
		String res="";
		for(int i=0;i<=str.length()-1;i++) {
			int result=Math.abs((int)str.charAt(i)-(int)str.charAt(i+1));
			//System.out.println();
			StringBuffer str2=new StringBuffer(Integer.toUnsignedString(result));
			str1.append(str2);
		}
		str1.append(str.length()-1);
		//System.out.println(str.charAt(str.length()-1));
		System.out.println(str);
		
	}

}
