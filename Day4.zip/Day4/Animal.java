package Day4;

public class Animal {
 String name="animal";
 void eat() {
	 System.out.println("all animal can eat");
 }
}
