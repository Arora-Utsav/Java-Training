package Day4;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account ac = new Account();
		ac.setAccHolder("Nagashree", 21);
		Person value = ac.getAccHolder();
		ac.setAccHolder("Chaya", 20);
		value = ac.getAccHolder();
		System.out.println(value);
	}

}


