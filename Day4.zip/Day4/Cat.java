package Day4;

public class Cat extends Animal {
 String name1="cat";
 void eat()
 {
	 System.out.println("cat eats");
 }
}
